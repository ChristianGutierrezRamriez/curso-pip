print('Hello World!')

def my_print():
  print('This is my print')
my_print()

def my_print2(text):
  print(text * 2)
my_print2('Este es mi texto')

def suma(a, b):
  print(a + b)
suma(1, 5)

def suma2(a, b):
  return a+b
print(suma2(1, 5))