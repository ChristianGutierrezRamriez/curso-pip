for i in range(1, 11):
  print(i)

my_iter = iter(range(1, 11))
print(my_iter)
print(next(my_iter))
print(next(my_iter))
print(next(my_iter))

