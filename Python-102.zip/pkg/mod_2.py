def func_3():
  return 'Func 3'

def func_4():
  return 'Func 4'