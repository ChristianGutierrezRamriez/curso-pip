#posterior a python 3.3 se puede usar init para inicializar variables
print('se inicio paquete pkg')

URL = 'platzi.com'

import pkg.mod_1, pkg.mod_2