def func_1():
  return 'Func 1'

def func_2():
  return 'Func 2'